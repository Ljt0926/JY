/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>

#ifdef _TDSCALC_ 
    #define TDSCALC   
#else
    #define TDSCALC extern
#endif

#ifndef _DISPLAY_H
#define _DISPLAY_H


    
#endif

/* [] END OF FILE */
