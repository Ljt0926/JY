/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#define _FUN_
#include "config.h"

uint8 Counter_Key;
/*******************************************************************************
*                       Buzzer
********************************************************************************/
void Buzzer_Fun(void)
{
    
	if(BUZfkg==1)//按键提示音
		{       
		    if(BuzzerDly<=2)
		        PWM_Start();
		    else
		    {
		        PWM_Stop();
		        BuzzerDly=0; 
		        BUZfkg=0;     
		    }
		}
	else if(BUZfkg==2)//上电缺水提示音 蜂鸣器响3次
		{ 
		BUZqueshuifkg=1;
		if(qushui_BUZcnt<3)
		{
		  if(BuzzerDly<5)
		      PWM_Start();
		  else if( BuzzerDly>=5 &&BuzzerDly<10)
		      PWM_Stop();
		  else if(BuzzerDly>=10) 
		  {   
		      qushui_BUZcnt++;
		      BuzzerDly=0;
		      //BUZfkg=0;
		      
		  }
		} 
		else
		{
		qushui_BUZcnt=0;
		BUZfkg=0;
		}   
		
		}  
	else if(BUZfkg==3)//滤芯寿命到期报警提示音  蜂鸣器2秒一次鸣叫15S  debug 叫3声
		{
			if(qushui_BUZcnt<7)//鸣叫7次14S
			{
			    if(BuzzerDly<20)
			        PWM_Start();
			    else if( BuzzerDly>=20 &&BuzzerDly<40)
			        PWM_Stop();
			    else if(BuzzerDly>=40) 
			    {   
			        qushui_BUZcnt++;
			        BuzzerDly=0;
			        //BUZfkg=0;
			        
			    }
			} 
		else
		{
		    qushui_BUZcnt=0;
		    BUZfkg=0;
		}   
		
		
		
		
		}
}


/********************************************************************************\
    Timer ISR FUN
    //10ms
\********************************************************************************/
void Timer_Isr_Fun(void)
{	

    if(T10msSign)
        T10msSign = 0;
    else
        return;
    TimeBase_Interrupt_CountOne++;
    TimeBase_Interrupt_CountTwo++;
    TimeBase_Interrupt_CountThree++;
    if(Ack_Timer>0)//应答时间设定
    	Ack_Timer--; 
    if(Tds_Ack_Timer>0)//应答时间设定
    	Tds_Ack_Timer--; 
    if(Send_Interval_Counter>0)
    	Send_Interval_Counter--;
    	
    	  	   
    if(fastjishifig==1)
        fastjishicnt++;
    else
        fastjishicnt=0; 
    if(BUZfkg==1||BUZfkg==2||BUZfkg==3)//蜂鸣器计时
    
        BuzzerDly++;
    
    else
    {
        BuzzerDly=0;
        qushui_BUZcnt=0;
    }
    if(Tds_Dispcnt<100)
    		Tds_Dispcnt++;
  	else
  		{
  			if(WorkFlag01_Dispcnt<3)
  				{
  					WorkFlag01_Dispcnt++;
					WorkFlag01.all=WorkFlag01.all<<1;
				}
			else
				{
					WorkFlag01.all=0x01;//显示初始化
					WorkFlag01_Dispcnt=0;//显示初始化
				}
  		 	Tds_Dispcnt=0;
  		}
    if(PowerOnOneHourCnt < 360000)
        PowerOnOneHourCnt++;
 
    	NbPressCnt++;

    	 WifiPressCnt++;

    	XzPressCnt++;

    
    FlashCnt++;
    if((WorkFlag.jishi==1)&&(WorkFlag.nowater==0))  //判断滤芯计时标志
    {
        if(fastjishifig==1)
        {
            jingshuiliang++;
            if(LvxinJishi[0]<2640)
                LvxinJishi[0]++;
            if(LvxinJishi[1]<3520)
                LvxinJishi[1]++;
            if(LvxinJishi[2]<23760)    
                LvxinJishi[2]++;
            if(LvxinJishi[3]<23760)    
                LvxinJishi[3]++;
            if(LvxinJishi[4]<23760)
                LvxinJishi[4]++;
            if(LvxinJishi[4]<5940)
                LvxinJishi[5]++;
        
        }   
        
        else
        {
        
            
             onemincnt++;
            if(onemincnt>=NBmint)
            {
                
                onemincnt=0;
                
                if(NBfig==1)
                {
                
                    if(LvxinJishi[0]<2640)
                        LvxinJishi[0]++;
                    if(LvxinJishi[1]<3520)
                        LvxinJishi[1]++;
                    if(LvxinJishi[2]<23760)    
                        LvxinJishi[2]++;
                    if(LvxinJishi[3]<23760)    
                        LvxinJishi[3]++;
                    if(LvxinJishi[4]<23760)
                        LvxinJishi[4]++;
                    if(LvxinJishi[4]<5940)
                        LvxinJishi[5]++;
                }
                
                else
                {
                    if(LvxinJishi[0]<3168)
                         LvxinJishi[0]++;
                    if(LvxinJishi[0]<4224)    
                        LvxinJishi[1]++;
                    if(LvxinJishi[0]<28512)    
                        LvxinJishi[2]++;
                    if(LvxinJishi[0]<28512)    
                        LvxinJishi[3]++;
                    if(LvxinJishi[0]<28512)
                        LvxinJishi[4]++;
                    if(LvxinJishi[0]<7128)
                        LvxinJishi[5]++;
                
                
                }
                
                
            }                   
        if(jingshuicnt<65500)
        jingshuicnt++;//净水量计数器
        if(jingshuicnt>TIMER1M_jingshui)//每60S 净水量加1
        {
        	if(jingshuiliang > 9999)
    				{   
        			jingshuiliang = 0;//9999;
        			EEjingshuiliang=0;
       				// write1();
    				}
            jingshuiliang++;
            jingshuicnt=0;
            
        }
       
        
        
        } 
        if(LianXuJiShi<80000)
        	LianXuJiShi++;
        
        
        
        
    }else
    {
        LianXuJiShi = 0;
    }
    
    StaFlashCnt++;
    if(StaFlashCnt > TIMER500MS)
    {
        StaFlashCnt = 0;
        DisFlag.sta = !DisFlag.sta;
    }

  	if(PowerOnCnt00<0xffff)
  		{
    		PowerOnCnt00++;
		    if(PowerOnCnt00>60000)//10min
		    //if(PowerOnCnt00>1)//10min
		    	{
		    		PowerOnCnt00=0;
		    		if(PowerOnCnt01<144)//24hour
		    			PowerOnCnt01++;
		    		else
		    			{
		    				WorkFlag02.poll_24H_value_sendingcmp=1;
		    				PowerOnCnt01=0;
		    				PowerOnCnt00=0;
		    			}
		    	}
	  	} 
    if(chongxifig==1)//冲洗状态且无故障就计时
        chongxicnt++;
    
    if(WorkFlag.quyuxzsta)//区域选择状态激活时开始计时
        NBstandcnt++;
    if(lXXZcnt_fig)//滤芯状态计时
        LXXZstandcnt++;
    if(DYWDfig==1&&DYWD_Read() ==0)//从无水到有水低压微动接通3S 计时 
        DYWDcnt++;
    else
       DYWDcnt=0;
    if(DYWDfig1==1&&DYWD_Read() ==1)//从有水到无水低压微动接通3S 计时 
        DYWDcnt1++;
    else
       DYWDcnt1=0;
    
    
    
    if(GYfig1==1&&GYWD_Read() ==1)//从到有水低压微动接通3S 计时 
        GYcnt1++;
    else
       GYcnt1=0;
    
    if(GYfig==1&&GYWD_Read() ==0)//从有水到无水低压微动接通3S 计时 
        GYcnt++;
    else
       GYcnt=0;
    
    
    
    
    if(lXXZcnt_fig)
    {
        if(LXXZstandcnt<400)//滤芯状态计时
             LXXZstandcnt++; 
    }
    else
        LXXZstandcnt=0;    
    
    
    if(Error_Data.bit.Error_00_flag==1)//连续制水2小时全屏闪烁
        eroorcnt++;
    else
        
        eroorcnt=0;
    
    if(standflashfig==1)//指示灯无闪烁计时
        standflashcnt++;
    else
        standflashcnt=0;
    if(standkeyfig==1)//按键无动作计时
        standkeycnt++;
    else
        standkeycnt=0;
    if(WorkFlag.zijiansta&&zijianstacnt<255) //自检状态计时
    
        zijianstacnt++;
    
    if(jserrorcntfig==1)
    	{
    		if(jserrorcnt<0xff)
        jserrorcnt++;
      }
    else
        jserrorcnt=0;
    
    if(yanshifig==1)
    {
    	if(yanshicnt<0xff)
        yanshicnt++;
    }
    else
        yanshicnt=0;
    
    if(fastfig==1)
    {
    	if(fastcnt<0xff)
        fastcnt++;
    }
    else
        fastcnt=0;
    
    
    
}


/********************************************************************************\
    USER FUNCTION
\********************************************************************************/
void stand(void)//待机判断
{
    /* 四个指示灯无闪烁   */
    if(DisFlag.workingsignflash==0&&DisFlag.outofwatersignflash==0&&DisFlag.cleaningsignflash==0&&DisFlag.errorsignflash==0)
        standflashfig=1;
    else
    {
        standflashfig=0;
        WorkFlag.standbysta=0; 
    }
     /* 四个按键无动作   */
    if((KEYNB)==0&&(KEYXZ)==0&&(KEYFW)==0&&(KEYQX)==0)
        standkeyfig=1;
    else 
    {
        standkeyfig=0;
        WorkFlag.standbysta=0; 
        
    } 
    /* 判断有没有滤芯寿命到期，有滤芯寿命到期的则不进待机   */
    if(SPercent==0||HPercent==0||JPercent==0||KPercent==0||LPercent==0||MPercent==0)
    {    
        standflashcnt=0;
        standkeycnt=0;
        WorkFlag.standbysta=0; 
        lvxindaoqifig=1;
        
    }    
    else
        lvxindaoqifig=0;
     /* 指示灯连续5分钟无闪烁且四个按键5分钟无动作,则进入待机状态   */
    if(standflashcnt>=TIMER5M&&standkeycnt>=TIMER5M&&lvxindaoqifig==0)
    {
        standflashcnt=0;
        standkeycnt=0;
        WorkFlag.standbysta=1;  
    }    
    
    
    
    

    
}


void lvxin_panduan(void)
{
    LXPercent();
    if(SPercent==1)
        Sfig=1;
    else if(SPercent==0)
        Sfig=2;
    
    if(HPercent==1)
        Hfig=1;
    else if(HPercent==0)
        Hfig=2;
    
    if(JPercent==1)
        Jfig=1;
    else if(JPercent==0)
        Jfig=2;
        
    if(KPercent==1)
        Kfig=1;
    else if(KPercent==0)
        Kfig=2;
    
    if(LPercent==1)
        Lfig=1;
    else if(LPercent==0)
        Lfig=2;
    
    if(MPercent==1)
        Mfig=1;
    else if(MPercent==0)
        Mfig=2;
    
}



void LXPercent(void)//滤芯百分比计算 函数
{
    
    if(NBfig==1)//如果是北方模式
	    {
	      if(LvxinJishi[0]<2640)
	          SPercent=(10-(LvxinJishi[0]/SP));//PP寿命百分比2400min
	      else
	          SPercent=0;
	      if(LvxinJishi[1]<3520)   
	          HPercent=(10-(LvxinJishi[1]/HP));//压缩活性炭寿命百分比
	      else
	          HPercent=0;
	      if(LvxinJishi[2]<23760)     
	          JPercent=(10-(LvxinJishi[2]/JP));//R01寿命百分比
	      else
	          JPercent=0;
	      if(LvxinJishi[3]<23760)   
	          KPercent=(10-(LvxinJishi[3]/KP));//R02寿命百分比
	      else
	          KPercent=0;
	      if(LvxinJishi[4]<23760)   
	          LPercent=(10-(LvxinJishi[4]/LP));//R03寿命百分比
	      else
	          LPercent=0;
	      if(LvxinJishi[5]<5940)    
	          MPercent=(10-(LvxinJishi[5]/MP));//载银寿命百分比
	      else
	          MPercent=0;
	    }
    else//如果是南方模式
	    {
	        SPercent=(10-(LvxinJishi[0]/SP_N));//PP寿命百分比
	        HPercent=(10-(LvxinJishi[1]/HP_N));//压缩活性炭寿命百分比
	        JPercent=(10-(LvxinJishi[2]/JP_N));//R01寿命百分比
	        KPercent=(10-(LvxinJishi[3]/KP_N));//R02寿命百分比
	        LPercent=(10-(LvxinJishi[4]/LP_N));//R03寿命百分比
	        MPercent=(10-(LvxinJishi[5]/MP_N));//载银寿命百分比
	    }
    if(Sfig==0)
    {   
        if(SPercent==2)
        {
            
            BUZfkg=3;
            Sfig=1;
        
        }
    }
    else if(Sfig==1)
    {   
        if(SPercent==1)
        {
            BUZfkg=3;
            Sfig=2;
            
        }
         
    
    }
    else if(Sfig==2)
    {
       if(SPercent==0)
        {
            DisFlag.slvxinflash=1;
            BUZfkg=3;
            Sfig=3;
        } 
       
    }
    else
        Sfig=0;
    
    if(SPercent==10)
    {
        DisFlag.slvxinflash=0;
       
    }
    
    
    
    if(Hfig==0)
    {   
        if(HPercent==2)
        {
            
            BUZfkg=3;
            Hfig=1;
        
        }
        
    }
    else if(Hfig==1)
    {
        if(HPercent==1)
        {
            
            BUZfkg=3;
            Hfig=2;
        
        }
    }   
    else if(Hfig==2)
    {
        if(HPercent==0)
        {
            
            BUZfkg=3;
            Hfig=3;
            DisFlag.hlvxinflash=1;
        
        }
    
    
    }
    else
         Hfig=0;
    if(HPercent==10)
        DisFlag.hlvxinflash=0;
    
    
    
    
    if(Jfig==0)
    {   
        if(JPercent==2)
        {
            
            BUZfkg=3;
            Jfig=1;
        
        }
        
    }
    else if(Jfig==1)
    {
        if(JPercent==1)
        {
            
            BUZfkg=3;
            Jfig=2;
        
        }
    }
    else if( Jfig==2)
    {
        if(JPercent==0)
        {
            DisFlag.jlvxinflash=1;
            BUZfkg=3;
            Jfig=3;
        
        }
    }
    else
         Jfig=0;
    if(JPercent==10)
        DisFlag.jlvxinflash=0;
    
    
    
    
    if(Kfig==0)
    {   
        if(KPercent==2)
        {
            
            BUZfkg=3;
            Kfig=1;
        }
        
    }
    else if(Kfig==1)
    {
        if(KPercent==1)
        {
            
            BUZfkg=3;
            Kfig=2;
        }
    }
    else if(Kfig==2)
    {
       if(KPercent==0)
        {
            DisFlag.klvxinflash=1;
            BUZfkg=3;
            Kfig=3;
        } 
    }
    else
        Kfig=0;
    if(KPercent==10)
        DisFlag.klvxinflash=0;
    
  
    
    
    if(Lfig==0)
    {   
        if(LPercent==2)
        {
            
            BUZfkg=3;
            Lfig=1;
        
        }
    }
    else if(Lfig==1)
    {
        if(LPercent==1)
        {
            
            BUZfkg=3;
            Lfig=2;
        
        }
    
    }
    else if(Lfig==2)
    {
        if(LPercent==0)
        {
            DisFlag.llvxinflash=1; 
            BUZfkg=3;
            Lfig=3;
        
        }
    
    }
    else
        Lfig=0;
    
    if(LPercent==10)
        DisFlag.llvxinflash=0;
    
    
    
    
    if(Mfig==0)
    {   
        if(MPercent==2)
        {
            
            BUZfkg=3;
            Mfig=1;
        
        }
        
    }
    else if(Mfig==1)
    {
        if(MPercent==1)
        {
            
            BUZfkg=3;
            Mfig=2;
        }
    }
    else if(Mfig==2)
    {
        if(MPercent==0)
        {
            DisFlag.mlvxinflash=1;
            BUZfkg=3;
            Mfig=3;
        }
    }
    else 
        Mfig=0;
    
    if(MPercent==10)
        DisFlag.mlvxinflash=0;  
}

void error_alm(void)//异常故障报警函数
{
    
    if(K1_Read()==0)//在进水和冲洗阀不工作的时候检测排线脱落************************************************
		  {
		      if(CX_Read()==1)//1时上电时CX端子脱落 
			      {    
			          Error_Data.bit.Error_02_flag=1;
                    if(ErrorFlag.Error_01==0)
                    {
                        ErrorFlag.Error_01=1;  
			            Load_Error(HOST_E1_DATA);
                     }
			      }
		      else
		      	{
			         Error_Data.bit.Error_02_flag=0;
		     		}	  
		  }    
    if(K2_Read()==0)
	    {
	    
	      if(JS_Read()==1)//进水1端子没有脱落,debug 
	      	{
	          Error_Data.bit.Error_01_flag=0;
	  			} 
	      else //上电的时候脱落              
	        {
	            jserrorcntfig=1;
	           if(jserrorcnt>5)
	           {
	              jserrorcntfig=0;
	            	Error_Data.bit.Error_01_flag=1;
                  if(ErrorFlag.Error_02==0)
                    {
                        ErrorFlag.Error_02=1;
                        Load_Error(HOST_E2_DATA);
                    }
	           }
	        }         
	    }
    if(Error_Data.bit.Error_02_flag==1||Error_Data.bit.Error_01_flag==1)//有故障则故障标志置1有端子脱落和无水************************************************
	    {   
	        WorkFlag.error=1;
	        DisFlag.errorsignflash=1;//故障指示灯闪烁
	    }    
    else
	    {
	       WorkFlag.error=0;  
	       DisFlag.errorsignflash=0;
	    }   
}      
    
void queshui_alm(void)

{
	if(LianXuJiShi>=TIMER2H)//连续工作超过120分钟报警 *****************************************************************
		{ 
			Load_Error(HOST_E0_DATA);
			Error_Data.bit.Error_00_flag=1;
    }
  else
    {
     	Error_Data.bit.Error_00_flag=0;  
    }   
    if(DYWD_Read()==1)//为1时无水//判断是否有自来水************************************************
	    {
	        if(DYWDfig1)//从有水到无水低压开关有3S 的延时,低压开关断开有3S的延时
	        {
	            if(DYWDcnt1>30*20*5)
	//            if(DYWDcnt1>30)
	            {   
	               DYWDfig1=0;
	               DYWDcnt1=0;
	             }    
	        }        
	        else
	        {
	            //无水，
	            DYWDfig=1;
	            Switch_Data.bit.diya_flag=1;
	            WorkFlag.nowater = 1;
	               
	        }            
	          
	   
	    }
    else    //有水
	    { 
	        if(DYWDfig==1)//标志等于1,则是无水到有水,低压开关延时3S 接通
	        {
	            if(DYWDcnt>30)
	            {
	                DYWDfig=0;
	                DYWDcnt=0;                
	            }
	            
	        }
	        else
	        {
	            Switch_Data.bit.diya_flag=0;
	            DYWDfig1=1;
	            WorkFlag.nowater = 0;       
	        }      
	    }                 
    if(GYWD_Read()==1) ///为1判断压力罐是否水满************************************************
	    {  
	        if(GYfig1==1)
	        {
	            if(GYcnt1>1)
	            {
	                GYcnt1=0;
	                GYfig1=0;
	            }
	        
	        }
	        else
	        {
	            shuibumanfig=0;
	            WorkFlag.gyfull = 1;//高开开关判断水满了
	            Switch_Data.bit.gaoya_flag=1;
	            GYfig=1;
	            waterfullfig=0;
	            
	            
	        }    
	                
	        
	        
	        
	        
	       
	    } 
    else//水不满
	    {      
	       if(GYfig==1)//从水满到到不满有1S延时
	        {
	            if(GYcnt>10)
	            {
	                GYfig=0;
	                GYcnt=0;
	            }    
	        }        
	        else
	        {
	            WorkFlag.gyfull =0;
	            GYfig1=1;
	            Switch_Data.bit.gaoya_flag=0;
	            if(waterfullfig==0)
	            {
	                if(gyfullcnt<254)
	                
	                gyfullcnt++;
	                waterfullfig=1;
	            }
	            if(shuibumanfig==0&&(SPercent==0||HPercent==0||JPercent==0||KPercent==0||LPercent==0||MPercent==0)&&lvxinbaojingcnt<2)
	            {
	                lvxinbaojingcnt++;
	                BUZfkg=3;
	                shuibumanfig=1;
	            }
	            
	            
	        }
	        
	     
	    }        
          



}
   
        
    

   
    
    
    
    
    
    
    
    
    
    
    
    
   
 

 
        
        
    

    
void jixing(void)//判断机型函数
{
    //jixingnumber=Read_jixingnumber() ;读机型号 
    switch(jixingnumber)
    {
        case 1:
            LedPannelBuf[S_CON] =0xffffe001;//如果为1号机型则 1号机型点亮
                    break;
        case 2:
            LedPannelBuf[H_CON] =0xffffe001;//如果为1号机型则 1号机型点亮
                    break;
        case 3:
            LedPannelBuf[J_CON] =0xffffe001;//如果为1号机型则 1号机型点亮
                    break;
        case 4:
            LedPannelBuf[K_CON] =0xffffe001;//如果为1号机型则 1号机型点亮
                    break;
        case 5:
            LedPannelBuf[L_CON] =0xffffe001;//如果为1号机型则 1号机型点亮
                    break;
        case 6:
            LedPannelBuf[M_CON] =0xffffe001;//如果为1号机型则 1号机型点亮
                    break;
                    
        break;
    } 
}   


void key(void)
{
      
    if(WorkFlag.quyuxzsta)//区域选择状态******************************************
    {
        
       if(NBstandcnt<TIMER30S) 
        {
        
            if((BtnData1 & (1 << BTN_NB))&&(!(BtnData2 & (1 << BTN_NB))))
            {
                NBstandcnt=0;
                BUZfkg=1;
               // WorkFlag.quyuxzsta = 0;
                NBfig^=0x01;
                if(NBfig==0)
                {
                    
                    NBmint=TIMER1MN; //如果是南方区域则计时时钟为TIMER1MN　南方的１分钟　
                    //DisFlag.south=1;
                    //DisFlag.north=0;
                }
                else if(NBfig==1)
                {
                    NBmint=TIMER1MB;//如果是北的话，为北方的一分钟
                    //DisFlag.south=0;
                   // DisFlag.north=1;
                }
            } 
            
            
            
            
            
        } 
        else
        {
            WorkFlag.quyuxzsta=0;
            NBstandcnt=0;
        }
        
    }  
    if(WorkFlag.lvxingxzsta)//滤芯选择状态
    {//滤芯选择状态********************************************************
           
            
        if(((BtnData1 & (1 << BTN_XZ))&&
           (BtnData2 & (1 << BTN_XZ)))||((BtnData1 & (1 << BTN_FW))&&(!(BtnData2 & (1 << BTN_FW))) )                              )
        {
            LXXZstandcnt=0;
            lXXZcnt_fig=0;
        }
        else
        {     
            lXXZcnt_fig=1;
                           //此段程序为在滤芯选择状态下30秒内部操作则退去滤芯选择状态
            if(LXXZstandcnt>=300)
            {
                lXXZcnt_fig=0;
              
                if(PressFlag.xzpressstart == 0)
                {             
               
                    PressFlag.xzpressstart = 1;
               
                    WorkFlag.lvxingxzsta = 0;
                    //WorkFlag.worksta = 1;
                    
                    WorkFlag.lxxz = 0;
                    LvXinNum1 = 0;
                    
                    DisFlag.sflash = 0;
                    DisFlag.hflash = 0;
                    DisFlag.jflash = 0;
                    DisFlag.kflash = 0;
                    DisFlag.lflash = 0;
                    DisFlag.mflash = 0;
                    
                    
                    return;
              
                }
            }   
                
                
        }  
        if((BtnData1 & (1 << BTN_XZ))&&
           (BtnData2 & (1 << BTN_XZ))&&
           (WorkFlag.lxfw == 1))
        {
            
            if(XzPressCnt > TIMER5S)
            {
                if(PressFlag.xzpressstart == 0)
                {             
               
                    PressFlag.xzpressstart = 1;
               
                    WorkFlag.lvxingxzsta = 0;
                    //WorkFlag.worksta = 1;
                    
                    WorkFlag.lxxz = 0;
                    LvXinNum1 = 0;
                    
                    DisFlag.sflash = 0;
                    DisFlag.hflash = 0;
                    DisFlag.jflash = 0;
                    DisFlag.kflash = 0;
                    DisFlag.lflash = 0;
                    DisFlag.mflash = 0;
                    
                    
                    return;
                }
            }
        }else
        {
            PressFlag.xzpressstart = 0;
            XzPressCnt = 0;
           // LXXZstandcnt=0;
        }
        
            //短按，滤芯选择
        if((BtnData1&0x04)&&
           (BtnData2 == 0))
        {
            
            LXXZOUT_fig=0;
            BUZfkg=1;
            LvXinNum = LvXinNum1;
            WorkFlag.lxxz = 1;
            
            LvXinNum1++;
             
            if(LvXinNum1 >= 6)
                LvXinNum1 = 0;
           
            WorkFlag.lxfw = 1;
        }
        //短按，滤芯复位
        if((BtnData1 & (1 << BTN_FW))&&(!(BtnData2 & (1 << BTN_FW))))
        {
              BUZfkg=1;  
                if(WorkFlag.yanshista==0)
	                {
	                    LvxinJishi[LvXinNum] = 0;
	                    LvxinJishi[LvXinNum+6]=0;
	                    Filter_Changed_Num[LvXinNum]+=1;
	                    Filter_Changed_Num[LvXinNum+6]+=1;
	                }
                else
	                {
	                    templvxin[LvXinNum]=0;  
	                }
                LXXZOUT_fig++;
                if( LXXZOUT_fig>=2)//如果在某一个滤芯复位时复位键按了2此 则退出滤芯选择状态
                {
                    LXXZOUT_fig=0;
                    if(PressFlag.xzpressstart == 0)
                    {             
                        PressFlag.xzpressstart = 1;            
                        WorkFlag.lvxingxzsta = 0;
                        WorkFlag.lxxz = 0;
                        LvXinNum1 = 0;           
                        DisFlag.sflash = 0;
                        DisFlag.hflash = 0;
                        DisFlag.jflash = 0;
                        DisFlag.kflash = 0;
                        DisFlag.lflash = 0;
                        DisFlag.mflash = 0;
                        return;
                    }
                }

                WorkFlag.lxfw = 1;
        }
        if(WorkFlag.lxxz == 1)
        {
            switch(LvXinNum)
            {
                case 0:
                    DisFlag.sflash = 1;
                    DisFlag.hflash = 0;
                    DisFlag.jflash = 0;
                    DisFlag.kflash = 0;
                    DisFlag.lflash = 0;
                    DisFlag.mflash = 0;
                    if(WorkFlag.yanshista==1)
                    	jixingnumber=1;
                    temps=templvxin[0];
                    
                    break;
                case 1:
                    DisFlag.sflash = 0;
                    DisFlag.hflash = 1;
                    DisFlag.jflash = 0;
                    DisFlag.kflash = 0;
                    DisFlag.lflash = 0;
                    DisFlag.mflash = 0;
                    if(WorkFlag.yanshista==1)
                    	jixingnumber=2;
                    temph=templvxin[1];
                    break;
                case 2:
                    DisFlag.sflash = 0;
                    DisFlag.hflash = 0;
                    DisFlag.jflash = 1;
                    DisFlag.kflash = 0;
                    DisFlag.lflash = 0;
                    DisFlag.mflash = 0;
                    if(WorkFlag.yanshista==1)
                    	jixingnumber=3;
                    tempj=templvxin[2];
                    break;
                case 3:
                    DisFlag.sflash = 0;
                    DisFlag.hflash = 0;
                    DisFlag.jflash = 0;
                    DisFlag.kflash = 1;
                    DisFlag.lflash = 0;
                    DisFlag.mflash = 0;
                    if(WorkFlag.yanshista==1)
                    	jixingnumber=4;
                    tempk=templvxin[3];
                    break;
                case 4:
                    DisFlag.sflash = 0;
                    DisFlag.hflash = 0;
                    DisFlag.jflash = 0;
                    DisFlag.kflash = 0;
                    DisFlag.lflash = 1;
                    DisFlag.mflash = 0;
                    if(WorkFlag.yanshista==1)
                    	jixingnumber=5;
                    templ=templvxin[4];
                    break;
                case 5:
                    DisFlag.sflash = 0;
                    DisFlag.hflash = 0;
                    DisFlag.jflash = 0;
                    DisFlag.kflash = 0;
                    DisFlag.lflash = 0;
                    DisFlag.mflash = 1;
                    if(WorkFlag.yanshista==1)
                    	jixingnumber=6;
                    tempm=templvxin[5];
                    break;
                default:
                    DisFlag.sflash = 0;
                    DisFlag.hflash = 0;
                    DisFlag.jflash = 0;
                    DisFlag.kflash = 0;
                    DisFlag.lflash = 0;
                    DisFlag.mflash = 0;
                    break;
            }
     
        }
    
    } 


 
   /* //工作状态***************************************************************
  长按南北键*/
    if((BtnData1 & (1 << BTN_NB))&&(BtnData2 & (1 << BTN_NB)))
    {
        if((NbPressCnt > TIMER5S)&&(PowerOnOneHourCnt < TIMER1H ))    // TIMER1H 500 * 100ms 5S
       {
            if(NBPressStart == 0)
            {
                NBPressStart =1;
                WorkFlag.quyuxzsta = 1;
                BUZfkg=1;
                if(NBfig==1)
									NBfig=0;                         
                else
									NBfig=1;                        
               return;
            }        
       }
    
    }
    else
    {       
        NBPressStart =0;
        NbPressCnt = 0;
    }
        //短按，手动保养键
    if((BtnData1 & (1 << BTN_SDBY))&&(!(BtnData2 & (1 << BTN_SDBY))))
    {
        BUZfkg=1;
       WorkFlag.shoudongbystabak = 1;   
    } 
		/*
		上电10S内同时按下选择键和复位键，持续到10S后进入商场演示状态
		 */
    if(((WorkFlag.lxxzwf == 0)||(WorkFlag.lxxzwf == 2)))               
    {
        //判断是否有选择键和复位键同时按下
        if(((BtnData1 & (1 << BTN_XZ))&&(BtnData2 & (1 << BTN_XZ)))&&
           ((BtnData1 & (1 << BTN_FW))&&(BtnData2 & (1 << BTN_FW)))&&
           (WorkFlag.lxxzwf == 0))
        {
            PressFlag.xzpressstart = 1;
            XzPressCnt = 0;
            WorkFlag.lxxzwf = 1;    //标志置1
        }        
        //长按选择键5S
        if((BtnData1 & (1 << BTN_XZ))&&(BtnData2 & (1 << BTN_XZ)))
        {
            if(XzPressCnt > TIMER5S)//debug
            {
                if(PressFlag.xzpressstart == 0)
                {
                    
                    PressFlag.xzpressstart = 1;
                    BUZfkg=1;
                    WorkFlag.lvxingxzsta = 1;
                    //WorkFlag.worksta = 0;
                    
                    DisFlag.sflash = 1;
                    DisFlag.hflash = 1;
                    DisFlag.jflash = 1;
                    DisFlag.kflash = 1;
                    DisFlag.lflash = 1;
                    DisFlag.mflash = 1;
             
                   return;
                }
            }
        }else
        {
            PressFlag.xzpressstart = 0;
            XzPressCnt = 0;
        }
        

       
        
    
    }            
    else if(WorkFlag.lxxzwf == 1)
    {
       if(PowerOnCnt00 <TIMER10S)
        {        
            //判断选择键和复位键是否持续同时按下
            if(((BtnData1 & (1 << BTN_XZ))&&(BtnData2 & (1 << BTN_XZ)))&&
               ((BtnData1 & (1 << BTN_FW))&&(BtnData2 & (1 << BTN_FW))))
            {                 
                yanshifig=1;                 
            }
            
            else
            {//否，其中一个键释放
                WorkFlag.lxxzwf = 2;
                 yanshifig=0;
                WorkFlag.yanshista=0;   
            }
            
        } 
        
        else
        {
            
            CyDelayUs(1);  
            if(((BtnData1 & (1 << BTN_XZ))&&(BtnData2 & (1 << BTN_XZ)))&&
               ((BtnData1 & (1 << BTN_FW))&&(BtnData2 & (1 << BTN_FW))))         
            {
                fastfig=1;           
            }    
            else
            {
                 WorkFlag.lxxzwf = 0;
                  fastfig=0;       
            }
  
        }
        
        

    }
   
             
   //判断是否南北键和选择键被同时按下

    if(((BtnData1 & (1 << BTN_XZ))&&(BtnData2 & (1 << BTN_XZ)))&&
       ((BtnData1 & (1 << BTN_NB))&&(BtnData2 & (1 << BTN_NB))))
		   {
			   	if(WifiPressCnt >TIMER1S)
			   		{
		        	WifiPressCnt = 0;  		
		        	Load_Command(MCU_POWERONSMARTLINK_DATA);
	  					BUZfkg=1;
	  				}
		   } 
		else
		 	{
			   WifiPressCnt = 0;
		 	} 	 
    if(yanshicnt>=TIMER5S) 
    	WorkFlag.yanshista=1;
    else if((fastcnt>=TIMER10S)&&(PowerOnCnt00<TIMER5MB)) 
    {
        fastfig=0;
        faststa=1;
    }   
    
    if(fastjishifig==1)
    {
        if(((KEYNB)==1||(KEYXZ)==1||(KEYFW)==1||(KEYQX)==1)||(fastjishicnt>=TIMER5M))
        {   
            
            BUZfkg=1;
            fastjishifig=0;
            cleareepromArrayflag=0;
            //CySoftwareReset();
            clean_ram();
        }    
    }
}
void Work_Fun_Init(void)
{

    
    DisFlag.working = 1;        //亮 工作中
    DisFlag.workingsign = 1;    //亮 水滴
    DisFlag.cleaning = 1;       //亮 清洗
    DisFlag.outofwater = 1;     //亮 缺水
    DisFlag.error = 1;          //亮 故障
    DisFlag.outofwatersign = 0;    
    DisFlag.errorsign = 0;  
    DisFlag.jsll = 1;
    DisFlag.cleaningsign=1;//上电水滴常亮
    DisFlag.outofwatersign=1;//缺水指示常亮
    DisFlag.errorsign=1;//故障指示也常亮
   
    LvXinNum1 = 0;

    NBmint=TIMER1MB;//默认为为北方计时
    WorkFlag.lvxingxzsta=0;
}
void Sys_Init(void)
{  
    jixingnumber=1;
    zijiandisplayfig=0;//上电首先进入自检
    WorkFlag.zijiansta=1;
    WorkFlag.shoucibysta=1;
    WorkFlag.nowater = 1;
    WorkFlag.shoudongbystabak=0;
    WorkFlag.uart_0_tx=1;
  	WorkFlag.poweroff=0;
  	WorkFlag.poweron=0;
  	WIFIPOWER_Write(0);   
    TDSPOWER_Write(0);
		WorkFlag01.all=0x01;//显示初始化
		WorkFlag01_Dispcnt=0;//显示初始化
		
  	Tds_Ack_Timer=30;
  	
  	Work_State.bit.waiting=1;
    Load_Command(MCU_HANDSHAKE_DATA);
    switch(jixingnumber)
	    {
	    case 1:
		    SP=240;
		    HP=320;
		    JP=2160;
		    KP=2160;
		    LP=2160;
		    MP=540;
		    SP_N=288;
		    HP_N=384;
		    JP_N=2592;
		    KP_N=2592;
		    LP_N=2592;
		    MP_N=648;
	    case 2:
	    	SP=240;
		    HP=320;
		    JP=2160;
		    KP=2160;
		    LP=2160;
		    MP=540;
		    SP_N=288;
		    HP_N=384;
		    JP_N=2592;
		    KP_N=2592;
		    LP_N=2592;
		    MP_N=648;
		  case 3:
	    	SP=240;
		    HP=320;
		    JP=2160;
		    KP=2160;
		    LP=2160;
		    MP=540;
		    SP_N=288;
		    HP_N=384;
		    JP_N=2592;
		    KP_N=2592;
		    LP_N=2592;
		    MP_N=648;
		  }
		if((Filter_Full_Data_Buf[0]>2)&&(Filter_Full_Data_Buf[3]>100))
			{
			SP=Filter_Full_Data_Buf[0]/10;
		    HP=Filter_Full_Data_Buf[1]/10;
		    JP=Filter_Full_Data_Buf[2]/10;
		    KP=Filter_Full_Data_Buf[3]/10;
		    LP=Filter_Full_Data_Buf[4]/10;
		    MP=Filter_Full_Data_Buf[5]/10;
		    SP_N=((Filter_Full_Data_Buf[0]*12)/100);
		    HP_N=((Filter_Full_Data_Buf[1]*12)/100);
		    JP_N=((Filter_Full_Data_Buf[2]*12)/100);
		    KP_N=((Filter_Full_Data_Buf[3]*12)/100);
		    LP_N=((Filter_Full_Data_Buf[4]*12)/100);
		    MP_N=((Filter_Full_Data_Buf[5]*12)/100);
				
			}
		  
}

void Wifi_Fun(void)
{


	switch(SmarkLink_State)
		{
			case WIFI_SENDDINGSTATE_DATA_NO_LINK_ROUTER://：无法连接路由器				      
				DisFlag.wifierror=1;
				DisFlag.wifilinkingsignflash=0;
				DisFlag.wifilinkingsign=0;			  				  					  					  					  					  					  					  				  					  					  				      
			  break;
			case WIFI_SENDDINGSTATE_DATA_NO_LINK_SERVER://01：无法连接服务器				      
				DisFlag.wifierror=1;
				DisFlag.wifilinkingsignflash=0;
				DisFlag.wifilinkingsign=0;		  				  				  					  					  					  					  					  					  				  					  					  				      
			  break;
			case WIFI_SENDDINGSTATE_DATA_LINK_ROUTER:	//：已经路由器（指示灯常亮）			      
				DisFlag.wifierror=0;
				DisFlag.wifilinkingsignflash=0;
				DisFlag.wifilinkingsign=1;			  				  					  					  					  					  					  					  				  					  					  				      
			  break;
			case WIFI_SENDDINGSTATE_DATA_LINK_SERVER:		//03：已连接服务器（指示灯常亮）		      
				DisFlag.wifierror=0;
				DisFlag.wifilinkingsignflash=0;
				DisFlag.wifilinkingsign=1;	   				  				  					  					  					  					  					  					  				  					  					  				      
			  break;
			case WIFI_SENDDINGSTATE_DATA_LINK_SMART_SETTING:		//已进入SmartLink等待App配置(指示灯可急闪)		      
				DisFlag.wifierror=0;
				DisFlag.wifilinkingsignflash=1;
				DisFlag.wifilinkingsign=0;					     				  				  					  					  					  					  					  					  				  					  					  				      
			  break;
			case WIFI_SENDDINGSTATE_DATA_LINK_SMART_SETTING_WAITTING:	//05：正在进SmartLink 配置中(指示灯慢闪)			      
				DisFlag.wifierror=0;
				DisFlag.wifilinkingsignflash=1;
				DisFlag.wifilinkingsign=0;	  
			  break;
			case WIFI_SENDDINGSTATE_DATA_SMART_SETTING_FAIL:	//06：SmartLink 配置失败
				DisFlag.wifierror=1;
				DisFlag.wifilinkingsignflash=0;
				DisFlag.wifilinkingsign=0;	 			      
			  break;
			case WIFI_SENDDINGSTATE_DATA_SMART_SETTING_OK:	//07：SmartLink配置成功（指示灯常亮同上02状态）	
				DisFlag.wifierror=0;
				DisFlag.wifilinkingsignflash=1;
				DisFlag.wifilinkingsign=0;	 			      			     				  				  					  					  					  					  					  					  				  					  					  				      
			  break;
			case WIFI_SENDDINGSTATE_DATA_SOFTAP:	//08：SoftAP状态	
				DisFlag.wifierror=0;
				DisFlag.wifilinkingsignflash=1;
				DisFlag.wifilinkingsign=0;	 	
				break;	
			default:
				DisFlag.wifierror=0;
				DisFlag.wifilinkingsignflash=0;
				DisFlag.wifilinkingsign=0;	 
				break;
		}					
}
void Work_Fun(void)
{  
	
    stand();//待机状态检测
    LXPercent();//滤芯寿命百分比
    if(WorkFlag.yanshista==0||faststa==0)
    	error_alm();//异常报警
    queshui_alm();
    Process_From_Wifi_Data();  
    Process_From_Tdsboard_Data(); 
    Uart_Exception_Handl();
 		Send_To_WifiUart();       

    if(NBfig==1)
    {
        DisFlag.north=1;//北
        DisFlag.south=0;   
        
    }
    else
    {
        DisFlag.north=0;//南
        DisFlag.south=1;    
    }
    key();//按键检测程序 
    if(WorkFlag02.poll_24H_value_sendingcmp==1)  
    	{
    		 WorkFlag02.poll_24H_value_sendingcmp=0;
    		 Load_Command(HOST_FILTER_USED_TIME_DATA);
    		 Load_Command(HOST_STATE_DATA);
    	}  
		if((WorkFlag.poweroff==1)&&(WorkFlag.poweron==0))//关机状态************************************************************
      {
          LedPannelBuf[0] = 0xffffffff;       //待机状态所有指示灯全灭
          LedPannelBuf[1] = 0xffffffff;
          LedPannelBuf[2] = 0xffffffff;
          LedPannelBuf[3] = 0xffffffff;
          LedPannelBuf[4] = 0xffffffff;
          LedPannelBuf[5] = 0xffffffff;
          LedPannelBuf[6] = 0xffffffff; 
          K1_Write(0);
    			K2_Write(0);
    			return;
      }        
   	else if((WorkFlag.poweroff==0)&&(WorkFlag.poweron==1))//开机状态************************************************************
      {
				WorkFlag.poweron=0;
      }   
    else if(WorkFlag.yanshista)//商场演示模式************************************************
    {
        if(yanshidisfig==0)
        {
            templvxin[0]=5;
            templvxin[1]=5;
            templvxin[2]=5;
            templvxin[3]=5;
            templvxin[4]=5;
            templvxin[5]=5;
            yanshidisfig=1;
        
        }        
        //长按选择键5S
        if((BtnData1 & (1 << BTN_XZ))&&(BtnData2 & (1 << BTN_XZ)))
        {
            if(XzPressCnt > TIMER5S)
            {
                if(PressFlag.xzpressstart == 0)
                {
                    
                    PressFlag.xzpressstart = 1;
                    BUZfkg=1;
                    WorkFlag.lvxingxzsta = 1;
                    //WorkFlag.worksta = 0;
                    
                    DisFlag.sflash = 1;
                    DisFlag.hflash = 1;
                    DisFlag.jflash = 1;
                    DisFlag.kflash = 1;
                    DisFlag.lflash = 1;
                    DisFlag.mflash = 1;
             
                   return;
                }
            }
        }
        else
        {
            PressFlag.xzpressstart = 0;
            XzPressCnt = 0;
        }
        
        
        K1_Write(0);
        K2_Write(0);
       
            
    } 
    else if(faststa)//快检模式************************************************
    {
        BUZfkg=1;
        fastcnt=0;
        fastjishifig=1;
        //V24_IN_ISR_Disable();//关外部中断  不保存数据
        cleareepromArrayflag=1;
        //cleareepromArray();
        clean_ram();
        SP=7;
        HP=9;
        JP=60;
        KP=60;
        LP=60;
        MP=15;
        faststa=0;
        return;   
    
    }      
    else if(WorkFlag.zijiansta) //开机上电自检模式************************************************
    {       
        if(zijianstacnt>10&&zijianstacnt<13)
        {
            BUZfkg=1;
            jixing();//机型判断及显示程序
        }
            
            
        else if(zijianstacnt>15&&zijianstacnt<18)  
        {
          switch(jixingnumber)
				    {          
				        case 1:
				            LedPannelBuf[S_CON] =0xffffffff;//如果为1号机型则 1号机型点亮
				            				        break;
				        case 2:
				            LedPannelBuf[H_CON] =0xffffffff;//如果为1号机型则 1号机型点亮
				            				        break;
				        case 3:
				            LedPannelBuf[J_CON] =0xffffffff;//如果为1号机型则 1号机型点亮
				            				        break;
				        case 4:
				            LedPannelBuf[K_CON] =0xffffffff;//如果为1号机型则 1号机型点亮
				            				        break;
				        case 5:
				            LedPannelBuf[L_CON] =0xffffffff;//如果为1号机型则 1号机型点亮
				            				        break;
				        case 6:
				            LedPannelBuf[M_CON] =0xffffffff;//如果为1号机型则 1号机型点亮
				            				        break;
				        break;
				    } 
        }
   
        else if(zijianstacnt>18&&zijianstacnt<28)
        {        
            LedPannelBuf[0] = 0;
            LedPannelBuf[1] = 0;
            LedPannelBuf[2] = 0;
            LedPannelBuf[3] = 0;
            LedPannelBuf[4] = 0;
            LedPannelBuf[5] = 0;
            LedPannelBuf[6] = 0;
              
        }
        else if(zijianstacnt>28&&zijianstacnt<30)
        {
            zijiandisplayfig=1;//机型和全屏检测后,可以开始正常的显示
            Work_Fun_Init();//正常显示开始给LED显示初始化
        }    
            
        
        if(zijianstacnt>30&&zijianstacnt<33)//如果无故障报警,3S后退出自检状态
        {    
            
            if(WorkFlag.nowater==1)
                BUZfkg=2;
        }  
        if(zijianstacnt>33&&Error_Data.bit.Error_01_flag==0&&Error_Data.bit.Error_02_flag==0&&WorkFlag.nowater==0)
        {
            WorkFlag.zijiansta=0;
         
            zijianstacnt=0;
        
        
        }
        else
        {
                        
            if(WorkFlag.nowater==1)
                DisFlag.outofwatersignflash =1;    
        
            
        
        
        
        
        }
        
        if(WorkFlag.nowater==0)  
            DisFlag.outofwatersignflash =0;  
        
       
    }
    
    else if(WorkFlag.nowater==1)//缺水故障状态,停止工作************************************************
    {
        
        
        DisFlag.outofwatersignflash =1; //缺水指示灯闪烁    
        
        workstartfig=0;//停止工作
        
        K1_Write(0);//关掉进水阀
        K2_Write(0);//关掉冲洗阀
        
        DisFlag.cleaningsignflash=0;//冲洗闪烁不闪烁
        DisFlag.workingsignflash =0;//制水工作指示灯不闪烁
        
     
        
        chongxifig=0;//冲洗有故障时冲洗计时标志清0 
        
        
        
        
    }
    else if(Error_Data.bit.Error_00_flag==1)//缺水故障状态,停止工作************************************************
    {
               
        workstartfig=0;//停止工作
        
        K1_Write(0);//关掉进水阀
        K2_Write(0);//关掉冲洗阀        
        chongxifig=0;//冲洗有故障时冲洗计时标志清0 
        
        
        
        
    }
    else if(WorkFlag.shoucibysta==1)//若果是首次上电,且无故障则进入首次冲洗状态************************************************
    {
       //故障排可以开始冲洗//有自来水,且压力罐水不满开始首次冲洗
                                                    
            DisFlag.outofwatersignflash =0;//进入首次上电冲洗,说明没故障,故障指示灯不闪
            
            chongxifig=1;//进入上电首次冲洗,则冲洗计时开始
            if(chongxicnt<600)//60S自动60*100ms=30S
           
            {   
                K1_Write(1);//打开进水阀
                K2_Write(1);//打开冲洗阀
                DisFlag.cleaningsignflash=1;//冲洗指示灯闪烁
            }    
            else
            {
                WorkFlag.shoucibysta=0;//首次上电冲洗完成后退出冲洗状态
                chongxifig=0;
                chongxicnt=0;       //冲洗计时器清0
                K1_Write(0);
                K2_Write(0);        //首次冲洗完成关闭进水和冲洗阀
                DisFlag.cleaningsignflash=0;//首次上电冲洗完成冲洗指示灯不闪烁
              
            }
            
        
      
    }        
        
    else
 
    {
        //WorkFlag.worksta=1;
        workstartfig=1;//故障排可以开始正常工作
        DisFlag.outofwatersignflash =0;//故障排除缺水指示灯不闪
        
    }
    
 //  if((workstartfig==1)&&(WorkFlag.nowater==0))   //自检模式无故障后开始正常工作模式************************************************************
   if(workstartfig)   //自检模式无故障后开始正常工作模式*****************
    {   
        
        
        if(gyfullcnt>=50&&WorkFlag.gyfull==1)//如果压力罐水满50次则自动冲洗debug
        	{                                      
            WorkFlag.zidongbysta=1;      
        	}
        //取水延后冲洗zhm
        if(WorkFlag.shoudongbystabak==1&&WorkFlag.gyfull==1)
          {                                       
        		WorkFlag.shoudongbysta=1;      			        	        
          }       
        if(WorkFlag.standbysta)//待机状态************************************************************
        {
          
            LedPannelBuf[0] = 0xffffffff;       //待机状态所有指示灯全灭
            LedPannelBuf[1] = 0xffffffff;
            LedPannelBuf[2] = 0xffffffff;
            LedPannelBuf[3] = 0xffffffff;
            LedPannelBuf[4] = 0xffffffff;
            LedPannelBuf[5] = 0xffffffff;
            LedPannelBuf[6] = 0xffffffff;
            if((KEYNB)==1||(KEYXZ)==1||(KEYFW)==1||(KEYQX)==1)//在待机状下点按任意键蜂鸣器有响应
                BUZfkg=1;
            if(WorkFlag.gyfull==0)//待机的时候如果压力罐水不满则退出待机
            {
                standflashcnt=0;
                standkeycnt=0;
                WorkFlag.standbysta=0;  
            
            }  
            
            
        
        }
        
        
        
        else if(WorkFlag.shoudongbysta)//手动保养模式***************************************************
        {
            
            DisFlag.workingsignflash =0;//制水指示灯不闪
            
            chongxifig=1;//进入手动保养状态 冲洗计时标志开始
            
            
//            if(chongxicnt < 450) //450 * 100ms = 45S
            if(chongxicnt < 600) //600 * 100ms = 60S
            {
               DisFlag.cleaningsignflash=1;
               K2_Write(1);    //打开冲洗电磁阀
               K1_Write(1);   //打开进水电磁阀 
            }
            else
            {
                WorkFlag.shoudongbysta = 0;
                //if(chongxicnt >=600)
                	WorkFlag.shoudongbystabak = 0;
                //WorkFlag.worksta = 1;
                chongxifig = 0;//手动保养结束清标志位
                chongxicnt=0;
                DisFlag.cleaningsignflash=0;
                K2_Write(0); 
                 
            }
            if(WorkFlag.gyfull==0)//如果在自动冲洗的时候检测高压开关闭合,则退出自动冲洗状态
            {
                WorkFlag.shoudongbysta = 0;
                //if(chongxicnt >= 600) 
                	//WorkFlag.shoudongbystabak = 1;
                //WorkFlag.worksta = 1;
                //chongxifig = 0;//手动保养结束清标志位
                // chongxicnt=0;
                DisFlag.cleaningsignflash=0;
                K2_Write(0);                                     
            }   
                
        }      
                     
                  
        else if(WorkFlag.zidongbysta)//自动保养模式*****************************
            
        {
           //BUZfkg=1;            
            DisFlag.workingsignflash =0;//制水指示灯不闪            
            chongxifig=1;//进入自动保养状态 冲洗计时标志开始                                    
            if(chongxicnt < 600) //600 * 100ms = 60S
            {
               DisFlag.cleaningsignflash=1;
               K2_Write(1);    //打开冲洗电磁阀
               K1_Write(1);   //打开进水电磁阀 ，
            }
            else
            {
                WorkFlag.zidongbysta = 0;
                //WorkFlag.worksta = 1;
                chongxifig = 0;//手动保养结束清标志位
                chongxicnt=0;
                if(gyfullcnt>=4)//zhm
                gyfullcnt=0;
                DisFlag.cleaningsignflash=0;
                K2_Write(0); 
                 
            }                           
            if(WorkFlag.gyfull==0)//如果在自动冲洗的时候检测高压开关闭合,则退出自动冲洗状态
            {
                
                WorkFlag.zidongbysta = 0;
                DisFlag.cleaningsignflash=0;
                K2_Write(0); 
            
            
            
            }                                    
        }    
           
//        else if(WorkFlag.gyfull==0&&WorkFlag.nowater==0)//制水模式,压力罐水不满时候*****************************
        else if(WorkFlag.gyfull==0)//制水模式,压力罐水不满时候*****************************
        {
            
            K1_Write(1);            //打开进水电子阀
            K2_Write(0); 
            DisFlag.cleaningsignflash=0;//冲洗指示灯不闪
            WorkFlag02.close_value_sendingcmp=1;
            DisFlag.workingsignflash =1;//制水指示灯开始闪烁
            WorkFlag.jishi = 1;     //开始寿命计数    
            if(WorkFlag02.open_value_sendingcmp==1)//开龙头发送完成标志	
            	{
            		WorkFlag02.open_value_sendingcmp=0;
            		Load_Command(HOST_FILTER_USED_TIME_DATA);
            	}
   
        }  
        else if(WorkFlag.gyfull==1) //压力罐水满)
        {
            K1_Write(0); //进水电磁阀关闭 
            DisFlag.workingsignflash =0;//水满停止制水灯不闪烁
            WorkFlag02.open_value_sendingcmp=1;
            WorkFlag.jishi = 0; //制水计时标志置0
            if(WorkFlag02.close_value_sendingcmp==1)//开龙头发送完成标志 
            	{
            		WorkFlag02.close_value_sendingcmp=0;
            		Load_Command(HOST_FILTER_USED_TIME_DATA);
            	}
        }        
            
         
      
            
    }    

    
          
}

/* [] END OF FILE */
