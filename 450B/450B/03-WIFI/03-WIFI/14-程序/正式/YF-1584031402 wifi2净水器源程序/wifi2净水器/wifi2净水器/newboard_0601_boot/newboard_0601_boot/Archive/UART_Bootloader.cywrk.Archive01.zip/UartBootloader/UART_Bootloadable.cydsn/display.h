/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>

#ifdef _DISPLAY_ 
    #define MYDIS   
#else
    #define MYDIS extern
#endif

#ifndef _DISPLAY_H
#define _DISPLAY_H

    /*************************************************00-[[[[[[****************\
        74HS164
    \*****************************************************************/
    MYDIS void S164_Trans_abyte(unsigned long ddata);
    
    
    /*****************************************************************\
        LED Pannel Display
    \*****************************************************************/
    MYDIS unsigned long LedPannelBuf[7];
    MYDIS unsigned long temp[7];
    MYDIS unsigned char templvxin[6];
    MYDIS unsigned int DigitalBuf;
    #define S_SHIFT     3
    #define S_CON   0
    MYDIS uint8 SPercent;//0-10-----0% - 100%
    #define H_SHIFT     3
    #define H_CON   1
    MYDIS uint8 HPercent;//0-10-----0% - 100%
    MYDIS unsigned int HData;
    #define J_SHIFT     3
    #define J_CON   2
    MYDIS uint8 JPercent;//0-10-----0% - 100%
    MYDIS unsigned int JData;
    #define K_SHIFT     3
    #define K_CON   3
    MYDIS uint8 KPercent;//0-10-----0% - 100%
    MYDIS unsigned int KData;
    #define L_SHIFT     3
    #define L_CON   4
    MYDIS uint8 LPercent;//0-10-----0% - 100%
    MYDIS unsigned int LData;
    #define M_SHIFT     3
    #define M_CON   5
    MYDIS uint8 MPercent;//0-10-----0% - 100%
    
    MYDIS uint8 FlashCnt;

    
//    LedPannelBuf[N1_CON] &= ~(1<<N1);
//    

    
    #define N1_CON      6
    #define N1      12
    #define N2_CON      6
    #define N2      11
    #define N3_CON      6
    #define N3      10
    #define N4_CON      6
    #define N4      9
    #define N5_CON      6
    #define N5      8
    #define N6_CON      6
    #define N6      7
    #define N7_CON      6
    #define N7      6
    #define N8_CON      6
    #define N8      5
    #define N9_CON      6
    #define N9      4
    #define N10_CON     6
    #define N10     3
    #define N11_CON     6
    #define N11     2
    #define N12_CON     6
    #define N12     1
    #define N13_CON     0
    #define N13     0
    #define N14_CON     1
    #define N14     0    
    #define N15_CON     2
    #define N15     0
    #define N16_CON     3
    #define N16     0
    #define N17_CON     4
    #define N17     0
    #define N18_CON     5
    #define N18     0
    #define N19_CON     6
    #define N19     0
    
    #define DIG1   17
    #define DIG2   16
    #define DIG3   15
    #define DIG4   14
    #define DIGACON    0
    #define DIGBCON    1
    #define DIGCCON    2
    #define DIGDCON    3
    #define DIGECON    4
    #define DIGFCON    5
    #define DIGGCON    6
    
    #define P1_CON      0
    #define P1      13
    #define P2_CON      1
    #define P2      13
    #define P3_CON      2
    #define P3      13
    #define P4_CON      3
    #define P4      13
    #define P5_CON      4
    #define P5      13    
    MYDIS struct{
        unsigned working:1;
        unsigned workingsign:1;
        unsigned outofwater:1;
        unsigned outofwatersign:1;
        unsigned south:1;
        unsigned north:1;
        unsigned cleaning:1;
        unsigned cleaningsign:1;
        unsigned error:1;
        unsigned errorsign:1;
        unsigned jsll:1;
        unsigned sflash:1;
        unsigned hflash:1;
        unsigned jflash:1;
        unsigned kflash:1;
        unsigned lflash:1;
        unsigned mflash:1;
        unsigned wifierror:1;	
        unsigned wifilinkingsign:1;		
        unsigned wifilinkingsignflash:1;		
        unsigned workingsignflash:1;
        unsigned outofwatersignflash:1;
        unsigned cleaningsignflash:1;
        unsigned errorsignflash:1;
        unsigned slvxinflash:1;
        unsigned hlvxinflash:1;
        unsigned jlvxinflash:1;
        unsigned klvxinflash:1;
        unsigned llvxinflash:1;
        unsigned mlvxinflash:1;
        unsigned sta:1;
        unsigned flashsta:1;
        unsigned :7;
    }DisFlag;
    MYDIS uint8 StaFlashCnt;
    
    MYDIS uint8 temps,temph,tempj,tempk,templ,tempm;

    
    MYDIS unsigned char LedPannelCnt;
    
    
    /*****************************************************************\
    \*****************************************************************/
    MYDIS void Led_Digital_Trans(unsigned char dig,unsigned char dt);
    MYDIS void Led_Pannel_Updata(void);
    MYDIS void Led_Pannel_Initial(void);
    MYDIS void Led_Pannel_Display(void);
    MYDIS void digital_updata(void);
    MYDIS void yanshidisplay(void);
    MYDIS void display8888(uint16 Value);    
    MYDIS void yanshi_Digital_Trans(unsigned char dig,unsigned char dt);
    
    
#endif

/* [] END OF FILE */
